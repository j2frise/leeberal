import config from "../config";
export default { 
    serverURI: config.serverURI,
    user: null,
    token: null
}