export default {
    serverURI: "http://api.leeberal.fr"
}