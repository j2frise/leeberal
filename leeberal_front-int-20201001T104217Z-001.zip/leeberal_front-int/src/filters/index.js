export function count(tab) {
    return tab.length
}